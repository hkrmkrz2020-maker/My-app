import express, { Request, Response } from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 3000;

// Data structures
export interface UserProfile {
  id: string; // 6-digit string: 000000 - 999999
  name: string;
  avatar: string;
  bio: string;
  createdAt: number;
  lastSeen: number;
  isOnline?: boolean;
}

export interface FriendRequest {
  id: string;
  fromId: string;
  toId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
  senderProfile?: UserProfile;
  receiverProfile?: UserProfile;
}

export interface ChatMessage {
  id: string;
  fromId: string;
  toId: string;
  text: string;
  mediaUrl?: string;
  timestamp: number;
  read: boolean;
}

// Storage persistence
const DATA_DIR = path.resolve(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DBData {
  users: Record<string, UserProfile>;
  friendRequests: FriendRequest[];
  friends: Record<string, string[]>; // userId -> array of friend userIds
  messages: ChatMessage[];
}

let db: DBData = {
  users: {},
  friendRequests: [],
  friends: {},
  messages: []
};

// Seed default welcome bot
const BOT_ID = '000100';
function seedInitialData() {
  if (fs.existsSync(DATA_FILE)) {
    try {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      db = JSON.parse(content);
    } catch (e) {
      console.error('Error loading db.json, using defaults', e);
    }
  }

  if (!db.users[BOT_ID]) {
    db.users[BOT_ID] = {
      id: BOT_ID,
      name: 'روبوت الدعم والترحيب 🤖',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=welcome_bot',
      bio: 'أنا هنا لمساعدتك واختبار الدردشة الفورية في أي وقت!',
      createdAt: Date.now(),
      lastSeen: Date.now(),
      isOnline: true
    };
  }

  // Pre-seed a couple of friendly demo IDs for testing
  const DEMO_IDS = [
    {
      id: '555777',
      name: 'سارة أحمد 🎨',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah555',
      bio: 'مصممة واجهات ومحبة للتقنية والقهوة ☕'
    },
    {
      id: '888999',
      name: 'عمر خالد 💻',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Omar888',
      bio: 'مبرمج تطبيقات ومحب للمراسلة البسيطة!'
    }
  ];

  for (const demo of DEMO_IDS) {
    if (!db.users[demo.id]) {
      db.users[demo.id] = {
        ...demo,
        createdAt: Date.now() - 1000000,
        lastSeen: Date.now() - 3600000,
        isOnline: false
      };
    }
  }

  saveData();
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save data:', err);
  }
}

seedInitialData();

// App and HTTP server
const app = express();
app.use(express.json({ limit: '10mb' }));

const server = http.createServer(app);

// WebSocket server
const wss = new WebSocketServer({ server, path: '/ws' });

// Track active sockets by userId
const activeSockets = new Map<string, WebSocket[]>();

function broadcastToUser(userId: string, payload: any) {
  const sockets = activeSockets.get(userId);
  if (sockets && sockets.length > 0) {
    const data = JSON.stringify(payload);
    sockets.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  }
}

function broadcastToAll(payload: any) {
  const data = JSON.stringify(payload);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

function isUserOnline(userId: string): boolean {
  if (userId === BOT_ID) return true;
  const sockets = activeSockets.get(userId);
  return !!sockets && sockets.length > 0;
}

wss.on('connection', (ws: WebSocket, req) => {
  let authenticatedUserId: string | null = null;

  try {
    const url = new URL(req.url || '', `http://${req.headers.host}`);
    const userId = url.searchParams.get('userId');
    if (userId && db.users[userId]) {
      authenticatedUserId = userId;
      if (!activeSockets.has(userId)) {
        activeSockets.set(userId, []);
      }
      activeSockets.get(userId)!.push(ws);

      // Mark online
      db.users[userId].isOnline = true;
      db.users[userId].lastSeen = Date.now();
      saveData();

      // Notify friends of presence
      broadcastToAll({
        type: 'presence_update',
        userId,
        isOnline: true,
        lastSeen: Date.now()
      });
    }
  } catch (e) {
    console.error('WS Connection parse error:', e);
  }

  ws.on('message', (messageData: string) => {
    try {
      const data = JSON.parse(messageData.toString());

      if (data.type === 'auth') {
        const userId = data.userId;
        if (userId && db.users[userId]) {
          authenticatedUserId = userId;
          if (!activeSockets.has(userId)) {
            activeSockets.set(userId, []);
          }
          if (!activeSockets.get(userId)!.includes(ws)) {
            activeSockets.get(userId)!.push(ws);
          }
          db.users[userId].isOnline = true;
          db.users[userId].lastSeen = Date.now();
          saveData();

          ws.send(JSON.stringify({ type: 'auth_success', userId }));
          broadcastToAll({
            type: 'presence_update',
            userId,
            isOnline: true,
            lastSeen: Date.now()
          });
        }
      } else if (data.type === 'chat_message') {
        const { fromId, toId, text, mediaUrl } = data;
        if (!fromId || !toId || (!text?.trim() && !mediaUrl)) return;

        const newMsg: ChatMessage = {
          id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
          fromId,
          toId,
          text: (text || '').trim(),
          mediaUrl: mediaUrl || undefined,
          timestamp: Date.now(),
          read: false
        };

        db.messages.push(newMsg);
        saveData();

        // Send to receiver
        broadcastToUser(toId, {
          type: 'new_message',
          message: newMsg,
          fromProfile: db.users[fromId]
        });

        // Send ack to sender
        broadcastToUser(fromId, {
          type: 'message_sent',
          message: newMsg
        });

        // If toId is Bot, generate an automatic friendly response!
        if (toId === BOT_ID) {
          setTimeout(() => {
            const botReplies = [
              `مرحباً بك! يسعدني جداً تواصلك. معرّفك الخاص هو [${fromId}]. يمكنك نسخه ومشاركته مع أي صديق لتتحدثا فورياً! 🚀`,
              `أهلاً وسهلاً! رسالتك وصلت بنجاح: "${newMsg.text}". النظام يعمل في الوقت الحقيقي وبكل سلاسة ⚡`,
              `هل جربت البحث عن معرّف صديق وإرسال طلب صداقة؟ يمكنك أيضاً تجربة المعرّفات المقترحة مثل 555777 أو 888999! ✨`,
              `تطبيق "دردشة المعرّف" يضمن خصوصيتك التامة، لا حاجة لبريد إلكتروني أو كلمة مرور أو أرقام هواتف! 🔒`,
              `أتمنى لك محادثات شيقة وممتعة! إذا كنت بحاجة لأي استفسار أنا هنا دائماً 😊`
            ];
            const randomReply = botReplies[Math.floor(Math.random() * botReplies.length)];
            const botMsg: ChatMessage = {
              id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
              fromId: BOT_ID,
              toId: fromId,
              text: randomReply,
              timestamp: Date.now(),
              read: true
            };
            db.messages.push(botMsg);
            saveData();

            broadcastToUser(fromId, {
              type: 'new_message',
              message: botMsg,
              fromProfile: db.users[BOT_ID]
            });
          }, 800);
        }
      } else if (data.type === 'typing') {
        const { fromId, toId, isTyping } = data;
        if (toId) {
          broadcastToUser(toId, {
            type: 'user_typing',
            fromId,
            isTyping: !!isTyping
          });
        }
      } else if (data.type === 'mark_read') {
        const { fromId, toId } = data;
        // mark messages from `toId` to `fromId` as read
        let modified = false;
        db.messages.forEach((m) => {
          if (m.fromId === toId && m.toId === fromId && !m.read) {
            m.read = true;
            modified = true;
          }
        });
        if (modified) {
          saveData();
          broadcastToUser(toId, {
            type: 'messages_read',
            byUserId: fromId
          });
        }
      }
    } catch (err) {
      console.error('Error handling WS message:', err);
    }
  });

  ws.on('close', () => {
    if (authenticatedUserId) {
      const userSockets = activeSockets.get(authenticatedUserId);
      if (userSockets) {
        const filtered = userSockets.filter((s) => s !== ws);
        if (filtered.length === 0) {
          activeSockets.delete(authenticatedUserId);
          if (db.users[authenticatedUserId]) {
            db.users[authenticatedUserId].isOnline = false;
            db.users[authenticatedUserId].lastSeen = Date.now();
            saveData();
          }
          broadcastToAll({
            type: 'presence_update',
            userId: authenticatedUserId,
            isOnline: false,
            lastSeen: Date.now()
          });
        } else {
          activeSockets.set(authenticatedUserId, filtered);
        }
      }
    }
  });
});

// Helper to generate a unique 6-digit ID
function generateUniqueId(): string {
  let id = '';
  let attempts = 0;
  do {
    const num = Math.floor(Math.random() * 1000000);
    id = num.toString().padStart(6, '0');
    attempts++;
  } while (db.users[id] && attempts < 10000);
  return id;
}

// REST APIs
// 1. Register or claim a random 6-digit ID
app.post('/api/register', (req: Request, res: Response) => {
  const { preferredId, name, avatar, bio } = req.body;

  let assignedId = preferredId;
  if (!assignedId || !/^\d{6}$/.test(assignedId)) {
    assignedId = generateUniqueId();
  }

  // If already exists, return existing profile
  if (db.users[assignedId]) {
    const user = { ...db.users[assignedId], isOnline: isUserOnline(assignedId) };
    return res.json({ success: true, user, isNew: false });
  }

  const defaultNames = ['مستخدم جديد', 'صديق', 'مغرد', 'رحال', 'سفير'];
  const randomName = defaultNames[Math.floor(Math.random() * defaultNames.length)] + ` #${assignedId.slice(-3)}`;

  const newUser: UserProfile = {
    id: assignedId,
    name: name?.trim() || randomName,
    avatar: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${assignedId}`,
    bio: bio?.trim() || 'مرحباً، أنا أستخدم دردشة المعرّف البسيطة!',
    createdAt: Date.now(),
    lastSeen: Date.now(),
    isOnline: true
  };

  db.users[assignedId] = newUser;
  if (!db.friends[assignedId]) {
    db.friends[assignedId] = [BOT_ID]; // Add welcome bot as default friend
  }
  if (!db.friends[BOT_ID].includes(assignedId)) {
    db.friends[BOT_ID].push(assignedId);
  }

  // Pre-seed a welcome message from the Bot
  db.messages.push({
    id: 'msg_welcome_' + Date.now(),
    fromId: BOT_ID,
    toId: assignedId,
    text: `أهلاً بك في تطبيق المراسلة! معرّفك الشخصي هو [${assignedId}]. يمكنك استخدامه فوراً ومشاركته مع الأصدقاء. جرب إرسال رسالة لي للبدء! 👋`,
    timestamp: Date.now(),
    read: false
  });

  saveData();

  return res.json({ success: true, user: newUser, isNew: true });
});

// 2. Get User Profile
app.get('/api/users/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const user = db.users[id];
  if (!user) {
    return res.status(404).json({ success: false, message: 'المعرّف غير موجود' });
  }
  return res.json({
    success: true,
    user: {
      ...user,
      isOnline: isUserOnline(id)
    }
  });
});

// 3. Search for a 6-digit ID
app.get('/api/search', (req: Request, res: Response) => {
  const queryId = (req.query.id as string || '').trim();
  if (!queryId) {
    return res.status(400).json({ success: false, message: 'يرجى إدخال معرّف للبحث' });
  }

  // Exact match or partial match for 6-digit
  const results = Object.values(db.users)
    .filter((u) => u.id === queryId || (queryId.length >= 3 && u.id.includes(queryId)))
    .map((u) => ({
      ...u,
      isOnline: isUserOnline(u.id)
    }));

  return res.json({ success: true, users: results });
});

// 4. Update Profile
app.post('/api/users/update', (req: Request, res: Response) => {
  const { id, name, avatar, bio } = req.body;
  if (!id || !db.users[id]) {
    return res.status(404).json({ success: false, message: 'المستخدم غير مسجل' });
  }

  const user = db.users[id];
  if (name !== undefined) user.name = name.trim();
  if (avatar !== undefined) user.avatar = avatar;
  if (bio !== undefined) user.bio = bio.trim();
  user.lastSeen = Date.now();

  saveData();

  broadcastToAll({
    type: 'profile_updated',
    user: {
      ...user,
      isOnline: isUserOnline(id)
    }
  });

  return res.json({ success: true, user });
});

// 5. Send Friend Request
app.post('/api/friends/request', (req: Request, res: Response) => {
  const { fromId, toId } = req.body;
  if (!fromId || !toId) {
    return res.status(400).json({ success: false, message: 'معلومات غير مكتملة' });
  }

  if (fromId === toId) {
    return res.status(400).json({ success: false, message: 'لا يمكنك إرسال طلب صداقة لنفسك' });
  }

  if (!db.users[toId]) {
    return res.status(404).json({ success: false, message: 'المعرّف المطلوب غير موجود' });
  }

  // Check if already friends
  const senderFriends = db.friends[fromId] || [];
  if (senderFriends.includes(toId)) {
    return res.status(400).json({ success: false, message: 'هذا المعرّف مضاف بالفعل في قائمة أصدقائك' });
  }

  // Check if pending request exists
  const existing = db.friendRequests.find(
    (r) => (r.fromId === fromId && r.toId === toId && r.status === 'pending') ||
           (r.fromId === toId && r.toId === fromId && r.status === 'pending')
  );

  if (existing) {
    if (existing.fromId === fromId) {
      return res.status(400).json({ success: false, message: 'لقد أرسلت طلباً بالفعل وهو قيد الانتظار' });
    } else {
      // Automatic accept if reverse request exists
      existing.status = 'accepted';
      if (!db.friends[fromId]) db.friends[fromId] = [];
      if (!db.friends[toId]) db.friends[toId] = [];
      if (!db.friends[fromId].includes(toId)) db.friends[fromId].push(toId);
      if (!db.friends[toId].includes(fromId)) db.friends[toId].push(fromId);
      saveData();

      broadcastToUser(fromId, { type: 'friend_request_accepted', friend: db.users[toId] });
      broadcastToUser(toId, { type: 'friend_request_accepted', friend: db.users[fromId] });

      return res.json({ success: true, message: 'تم قبول الصداقة المتبادلة بنجاح!', status: 'accepted' });
    }
  }

  const newRequest: FriendRequest = {
    id: 'req_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    fromId,
    toId,
    status: 'pending',
    createdAt: Date.now()
  };

  db.friendRequests.push(newRequest);
  saveData();

  // Notify receiver via WS
  broadcastToUser(toId, {
    type: 'new_friend_request',
    request: {
      ...newRequest,
      senderProfile: db.users[fromId]
    }
  });

  return res.json({
    success: true,
    message: 'تم إرسال طلب الصداقة بنجاح',
    request: {
      ...newRequest,
      receiverProfile: db.users[toId]
    }
  });
});

// 6. View Sent Friend Requests (رؤية الأصدقاء الذين أرسلت لهم طلب)
app.get('/api/friends/sent-requests/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const sent = db.friendRequests
    .filter((r) => r.fromId === id)
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((r) => ({
      ...r,
      receiverProfile: db.users[r.toId] ? {
        ...db.users[r.toId],
        isOnline: isUserOnline(r.toId)
      } : undefined
    }));

  return res.json({ success: true, requests: sent });
});

// 7. View Received Friend Requests
app.get('/api/friends/received-requests/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const received = db.friendRequests
    .filter((r) => r.toId === id && r.status === 'pending')
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((r) => ({
      ...r,
      senderProfile: db.users[r.fromId] ? {
        ...db.users[r.fromId],
        isOnline: isUserOnline(r.fromId)
      } : undefined
    }));

  return res.json({ success: true, requests: received });
});

// 8. Respond to Friend Request (Accept / Reject)
app.post('/api/friends/respond', (req: Request, res: Response) => {
  const { requestId, action } = req.body; // action: 'accept' | 'reject'
  const request = db.friendRequests.find((r) => r.id === requestId);
  if (!request) {
    return res.status(404).json({ success: false, message: 'طلب الصداقة غير موجود' });
  }

  if (action === 'accept') {
    request.status = 'accepted';
    const { fromId, toId } = request;

    if (!db.friends[fromId]) db.friends[fromId] = [];
    if (!db.friends[toId]) db.friends[toId] = [];

    if (!db.friends[fromId].includes(toId)) db.friends[fromId].push(toId);
    if (!db.friends[toId].includes(fromId)) db.friends[toId].push(fromId);

    saveData();

    // Notify both users
    broadcastToUser(fromId, {
      type: 'friend_request_accepted',
      requestId,
      friend: db.users[toId]
    });
    broadcastToUser(toId, {
      type: 'friend_request_accepted',
      requestId,
      friend: db.users[fromId]
    });

    return res.json({ success: true, message: 'تم قبول طلب الصداقة بنجاح' });
  } else {
    request.status = 'rejected';
    saveData();

    broadcastToUser(request.fromId, {
      type: 'friend_request_rejected',
      requestId
    });

    return res.json({ success: true, message: 'تم رفض طلب الصداقة' });
  }
});

// 9. Cancel / Delete Sent Request
app.delete('/api/friends/request/:requestId', (req: Request, res: Response) => {
  const { requestId } = req.params;
  const idx = db.friendRequests.findIndex((r) => r.id === requestId);
  if (idx !== -1) {
    db.friendRequests.splice(idx, 1);
    saveData();
  }
  return res.json({ success: true, message: 'تم إلغاء الطلب' });
});

// 10. Get Friends List
app.get('/api/friends/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const friendIds = db.friends[id] || [];

  const friendsList = friendIds
    .map((fId) => db.users[fId])
    .filter(Boolean)
    .map((friend) => {
      // Find last message
      const lastMsg = db.messages
        .filter((m) => (m.fromId === id && m.toId === friend.id) || (m.fromId === friend.id && m.toId === id))
        .sort((a, b) => b.timestamp - a.timestamp)[0];

      // Unread count
      const unreadCount = db.messages.filter((m) => m.fromId === friend.id && m.toId === id && !m.read).length;

      return {
        ...friend,
        isOnline: isUserOnline(friend.id),
        lastMessage: lastMsg || null,
        unreadCount
      };
    })
    .sort((a, b) => {
      const timeA = a.lastMessage?.timestamp || 0;
      const timeB = b.lastMessage?.timestamp || 0;
      return timeB - timeA;
    });

  return res.json({ success: true, friends: friendsList });
});

// 11. Get Chat Messages
app.get('/api/messages/:id/:otherId', (req: Request, res: Response) => {
  const { id, otherId } = req.params;

  const chatMessages = db.messages
    .filter((m) => (m.fromId === id && m.toId === otherId) || (m.fromId === otherId && m.toId === id))
    .sort((a, b) => a.timestamp - b.timestamp);

  // Mark messages from otherId as read
  let updated = false;
  chatMessages.forEach((m) => {
    if (m.fromId === otherId && m.toId === id && !m.read) {
      m.read = true;
      updated = true;
    }
  });
  if (updated) {
    saveData();
    broadcastToUser(otherId, { type: 'messages_read', byUserId: id });
  }

  return res.json({ success: true, messages: chatMessages });
});

// 12. Send message via HTTP fallback
app.post('/api/messages', (req: Request, res: Response) => {
  const { fromId, toId, text, mediaUrl } = req.body;
  if (!fromId || !toId || (!text?.trim() && !mediaUrl)) {
    return res.status(400).json({ success: false, message: 'البيانات غير مكتملة' });
  }

  const newMsg: ChatMessage = {
    id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    fromId,
    toId,
    text: (text || '').trim(),
    mediaUrl: mediaUrl || undefined,
    timestamp: Date.now(),
    read: false
  };

  db.messages.push(newMsg);
  saveData();

  broadcastToUser(toId, {
    type: 'new_message',
    message: newMsg,
    fromProfile: db.users[fromId]
  });

  return res.json({ success: true, message: newMsg });
});

// 13. Remove Friend
app.delete('/api/friends/:id/:friendId', (req: Request, res: Response) => {
  const { id, friendId } = req.params;
  if (db.friends[id]) {
    db.friends[id] = db.friends[id].filter((f) => f !== friendId);
  }
  if (db.friends[friendId]) {
    db.friends[friendId] = db.friends[friendId].filter((f) => f !== id);
  }
  saveData();

  return res.json({ success: true, message: 'تم إزالة الصديق' });
});

// Vite dev server middleware or static serve
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`🚀 ID Chat Server is running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
