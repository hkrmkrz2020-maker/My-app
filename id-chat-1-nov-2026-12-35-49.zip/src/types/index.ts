export interface UserProfile {
  id: string; // 6 digits: 000000 - 999999
  name: string;
  avatar: string;
  bio: string;
  createdAt: number;
  lastSeen: number;
  isOnline?: boolean;
}

export interface FriendRequest {
  id: string;
  fromId: string;
  toId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
  senderProfile?: UserProfile;
  receiverProfile?: UserProfile;
}

export interface ChatMessage {
  id: string;
  fromId: string;
  toId: string;
  text: string;
  mediaUrl?: string;
  timestamp: number;
  read: boolean;
}

export interface FriendItem extends UserProfile {
  lastMessage?: ChatMessage | null;
  unreadCount?: number;
}
