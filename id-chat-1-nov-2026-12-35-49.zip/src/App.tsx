/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { UserProfile, FriendRequest, ChatMessage, FriendItem } from './types';
import { Navbar } from './components/Navbar';
import { ChatSidebar } from './components/ChatSidebar';
import { ChatWindow } from './components/ChatWindow';
import { ProfileModal } from './components/ProfileModal';
import { SearchModal } from './components/SearchModal';
import { RequestsModal } from './components/RequestsModal';
import { IdentitySetupModal } from './components/IdentitySetupModal';
import {
  MessageSquare,
  Sparkles,
  Users,
  Copy,
  Check,
  Send,
  ExternalLink,
  Shield,
  RefreshCw,
  Bell
} from 'lucide-react';

const STORAGE_KEY = 'id_chat_user_id';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [friends, setFriends] = useState<FriendItem[]>([]);
  const [activeFriend, setActiveFriend] = useState<FriendItem | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [sentRequests, setSentRequests] = useState<FriendRequest[]>([]);
  const [receivedRequests, setReceivedRequests] = useState<FriendRequest[]>([]);

  // Modals state
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isRequestsOpen, setIsRequestsOpen] = useState(false);
  const [requestsInitialTab, setRequestsInitialTab] = useState<'sent' | 'received'>('sent');
  const [isIdentityModalOpen, setIsIdentityModalOpen] = useState(false);

  // Connection & realtime state
  const [isConnected, setIsConnected] = useState(false);
  const [isFriendTyping, setIsFriendTyping] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isLoadingApp, setIsLoadingApp] = useState(true);

  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const activeFriendIdRef = useRef<string | null>(null);

  // Keep activeFriendIdRef synchronized for WS callbacks
  useEffect(() => {
    activeFriendIdRef.current = activeFriend ? activeFriend.id : null;
  }, [activeFriend]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // 1. Fetch Sent & Received Requests
  const loadRequests = useCallback(async (userId: string) => {
    try {
      const [sentRes, recvRes] = await Promise.all([
        fetch(`/api/friends/sent-requests/${userId}`),
        fetch(`/api/friends/received-requests/${userId}`)
      ]);
      const sentData = await sentRes.json();
      const recvData = await recvRes.json();

      if (sentData.success) {
        setSentRequests(sentData.requests);
      }
      if (recvData.success) {
        setReceivedRequests(recvData.requests);
      }
    } catch (err) {
      console.error('Error fetching requests:', err);
    }
  }, []);

  // 2. Fetch Friends
  const loadFriends = useCallback(async (userId: string) => {
    try {
      const res = await fetch(`/api/friends/${userId}`);
      const data = await res.json();
      if (data.success) {
        setFriends(data.friends);
      }
    } catch (err) {
      console.error('Error fetching friends:', err);
    }
  }, []);

  // 3. Fetch Messages for active friend
  const loadMessages = useCallback(async (userId: string, friendId: string) => {
    try {
      const res = await fetch(`/api/messages/${userId}/${friendId}`);
      const data = await res.json();
      if (data.success) {
        setMessages(data.messages);
      }
    } catch (err) {
      console.error('Error fetching messages:', err);
    }
  }, []);

  // 4. WebSocket setup
  const connectWebSocket = useCallback((userId: string) => {
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws?userId=${userId}`;

    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setIsConnected(true);
      ws.send(JSON.stringify({ type: 'auth', userId }));
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        switch (data.type) {
          case 'new_message': {
            const { message, fromProfile } = data;
            const currentActiveId = activeFriendIdRef.current;

            if (currentActiveId === message.fromId) {
              setMessages((prev) => [...prev, message]);
              // Mark as read
              ws.send(JSON.stringify({
                type: 'mark_read',
                fromId: userId,
                toId: message.fromId
              }));
            } else {
              // Notification for message from someone else
              showToast(`رسالة جديدة من ${fromProfile?.name || message.fromId}: ${message.text || 'صورة'}`);
            }

            // Update friends list with last message
            loadFriends(userId);
            break;
          }

          case 'message_sent': {
            const { message } = data;
            setMessages((prev) => {
              // Check if already in list
              if (prev.some((m) => m.id === message.id)) return prev;
              return [...prev, message];
            });
            loadFriends(userId);
            break;
          }

          case 'user_typing': {
            const { fromId, isTyping } = data;
            if (activeFriendIdRef.current === fromId) {
              setIsFriendTyping(isTyping);
            }
            break;
          }

          case 'presence_update': {
            const { userId: targetId, isOnline, lastSeen } = data;
            setFriends((prev) =>
              prev.map((f) =>
                f.id === targetId ? { ...f, isOnline, lastSeen } : f
              )
            );
            setActiveFriend((prev) =>
              prev && prev.id === targetId ? { ...prev, isOnline, lastSeen } : prev
            );
            break;
          }

          case 'new_friend_request': {
            const { request } = data;
            showToast(`طلب صداقة جديد من ${request.senderProfile?.name || request.fromId}!`);
            loadRequests(userId);
            break;
          }

          case 'friend_request_accepted': {
            const { friend } = data;
            showToast(`تم قبول طلب الصداقة من قبل ${friend?.name || 'الصديق'}! 🎉`);
            loadRequests(userId);
            loadFriends(userId);
            break;
          }

          case 'friend_request_rejected': {
            showToast('تم رفض طلب الصداقة');
            loadRequests(userId);
            break;
          }

          case 'messages_read': {
            // Update messages to read
            setMessages((prev) =>
              prev.map((m) => (m.fromId === userId ? { ...m, read: true } : m))
            );
            break;
          }

          case 'profile_updated': {
            const { user: updatedUser } = data;
            setFriends((prev) =>
              prev.map((f) => (f.id === updatedUser.id ? { ...f, ...updatedUser } : f))
            );
            setActiveFriend((prev) =>
              prev && prev.id === updatedUser.id ? { ...prev, ...updatedUser } : prev
            );
            break;
          }
        }
      } catch (err) {
        console.error('Error handling WS event:', err);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      // Auto-reconnect after 3 seconds
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = setTimeout(() => {
        if (currentUser) {
          connectWebSocket(currentUser.id);
        }
      }, 3000);
    };

    ws.onerror = (err) => {
      console.error('WebSocket error:', err);
    };

    socketRef.current = ws;
  }, [currentUser, loadFriends, loadRequests]);

  // 5. Initialize or Register User
  const initUser = async (preferredId?: string, preferredName?: string) => {
    setIsLoadingApp(true);
    try {
      const storedId = preferredId || localStorage.getItem(STORAGE_KEY) || undefined;

      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          preferredId: storedId,
          name: preferredName
        })
      });

      const data = await res.json();
      if (data.success && data.user) {
        setCurrentUser(data.user);
        localStorage.setItem(STORAGE_KEY, data.user.id);

        // Load friends and requests
        await Promise.all([
          loadFriends(data.user.id),
          loadRequests(data.user.id)
        ]);

        // Connect socket
        connectWebSocket(data.user.id);
      }
    } catch (err) {
      console.error('Init user error:', err);
    } finally {
      setIsLoadingApp(false);
    }
  };

  useEffect(() => {
    initUser();
    return () => {
      if (socketRef.current) socketRef.current.close();
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
    };
  }, []);

  // When active friend changes, load messages
  useEffect(() => {
    if (currentUser && activeFriend) {
      loadMessages(currentUser.id, activeFriend.id);
      setIsFriendTyping(false);
    } else {
      setMessages([]);
    }
  }, [activeFriend, currentUser, loadMessages]);

  // User Actions
  const handleUpdateProfile = async (updated: Partial<UserProfile>) => {
    if (!currentUser) return;
    try {
      const res = await fetch('/api/users/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: currentUser.id,
          ...updated
        })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentUser(data.user);
        showToast('تم تحديث ملف الحساب بنجاح ✨');
      }
    } catch (err) {
      console.error(err);
      showToast('حدث خطأ أثناء حفظ الملف الشخصي');
    }
  };

  const handleSendFriendRequest = async (targetId: string): Promise<boolean> => {
    if (!currentUser) return false;
    try {
      const res = await fetch('/api/friends/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromId: currentUser.id,
          toId: targetId
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message || 'تم إرسال طلب الصداقة بنجاح 🚀');
        loadRequests(currentUser.id);
        if (data.status === 'accepted') {
          loadFriends(currentUser.id);
        }
        return true;
      } else {
        showToast(data.message || 'تعذر إرسال الطلب');
        return false;
      }
    } catch (err) {
      console.error(err);
      showToast('حدث خطأ أثناء إرسال طلب الصداقة');
      return false;
    }
  };

  const handleAcceptRequest = async (requestId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch('/api/friends/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestId,
          action: 'accept'
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم قبول الصداقة بنجاح! يمكنك الآن بدء المراسلة 🎉');
        await Promise.all([
          loadRequests(currentUser.id),
          loadFriends(currentUser.id)
        ]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRejectRequest = async (requestId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch('/api/friends/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestId,
          action: 'reject'
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم رفض الطلب');
        loadRequests(currentUser.id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCancelSentRequest = async (requestId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/friends/request/${requestId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم إلغاء الطلب المرسل');
        loadRequests(currentUser.id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSendMessage = async (text: string, mediaUrl?: string) => {
    if (!currentUser || !activeFriend) return;

    // Send via WebSocket
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'chat_message',
          fromId: currentUser.id,
          toId: activeFriend.id,
          text,
          mediaUrl
        })
      );
    } else {
      // Fallback via HTTP
      try {
        const res = await fetch('/api/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fromId: currentUser.id,
            toId: activeFriend.id,
            text,
            mediaUrl
          })
        });
        const data = await res.json();
        if (data.success) {
          setMessages((prev) => [...prev, data.message]);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleSendTyping = (isTyping: boolean) => {
    if (!currentUser || !activeFriend) return;
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'typing',
          fromId: currentUser.id,
          toId: activeFriend.id,
          isTyping
        })
      );
    }
  };

  const handleRemoveFriend = async (friendId: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/friends/${currentUser.id}/${friendId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم حذف الصديق');
        setActiveFriend(null);
        loadFriends(currentUser.id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (isLoadingApp || !currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-center">
        <div className="w-16 h-16 rounded-3xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4 animate-pulse">
          <MessageSquare className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">دردشة المعرّف - ID Chat</h2>
        <p className="text-sm text-slate-400 max-w-xs">
          جارٍ تهيئة معرّفك الشخصي والاتصال بالخادم...
        </p>
      </div>
    );
  }

  const friendsIds = friends.map((f) => f.id);
  const sentRequestIds = sentRequests.filter((r) => r.status === 'pending').map((r) => r.toId);

  return (
    <div className="h-screen w-screen overflow-hidden bg-slate-950 flex flex-col text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <Navbar
        currentUser={currentUser}
        isConnected={isConnected}
        pendingRequestsCount={receivedRequests.length}
        sentRequestsCount={sentRequests.length}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenRequests={(initialTab = 'sent') => {
          setRequestsInitialTab(initialTab);
          setIsRequestsOpen(true);
        }}
        onNewIdentity={() => setIsIdentityModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 flex overflow-hidden relative">
        {/* Friends Sidebar (Hidden on mobile if a friend is selected) */}
        <div className={`${activeFriend ? 'hidden md:flex' : 'flex'} w-full md:w-auto h-full`}>
          <ChatSidebar
            friends={friends}
            activeFriendId={activeFriend?.id || null}
            onSelectFriend={(friend) => setActiveFriend(friend)}
            onOpenSearch={() => setIsSearchOpen(true)}
            currentUserId={currentUser.id}
          />
        </div>

        {/* Chat Area (Hidden on mobile if no friend selected) */}
        <div className={`${!activeFriend ? 'hidden md:flex' : 'flex'} flex-1 h-full`}>
          <ChatWindow
            currentUserId={currentUser.id}
            activeFriend={activeFriend}
            messages={messages}
            isTyping={isFriendTyping}
            onSendMessage={handleSendMessage}
            onSendTyping={handleSendTyping}
            onBackToSidebar={() => setActiveFriend(null)}
            onRemoveFriend={handleRemoveFriend}
            onOpenSearch={() => setIsSearchOpen(true)}
          />
        </div>
      </main>

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-indigo-500/40 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-fade-in backdrop-blur-md">
          <Bell className="w-4 h-4 text-indigo-400 shrink-0" />
          <span className="text-xs md:text-sm font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Profile Modal */}
      <ProfileModal
        user={currentUser}
        friendsCount={friends.length}
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onUpdate={handleUpdateProfile}
      />

      {/* Search 6-digit ID Modal */}
      <SearchModal
        currentUserId={currentUser.id}
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        friendsIds={friendsIds}
        sentRequestIds={sentRequestIds}
        onSendFriendRequest={handleSendFriendRequest}
        onOpenChat={(targetUser) => {
          const existingFriend = friends.find((f) => f.id === targetUser.id);
          if (existingFriend) {
            setActiveFriend(existingFriend);
          } else {
            setActiveFriend({ ...targetUser });
          }
        }}
      />

      {/* Friend Requests Modal (Sent & Received) */}
      <RequestsModal
        isOpen={isRequestsOpen}
        onClose={() => setIsRequestsOpen(false)}
        sentRequests={sentRequests}
        receivedRequests={receivedRequests}
        initialTab={requestsInitialTab}
        onAcceptRequest={handleAcceptRequest}
        onRejectRequest={handleRejectRequest}
        onCancelSentRequest={handleCancelSentRequest}
        onOpenChat={(user) => {
          const friend = friends.find((f) => f.id === user.id) || { ...user };
          setActiveFriend(friend);
        }}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Identity Setup / Generator Modal */}
      <IdentitySetupModal
        isOpen={isIdentityModalOpen}
        onClose={() => setIsIdentityModalOpen(false)}
        currentId={currentUser.id}
        onSelectId={async (id, name) => {
          await initUser(id, name);
          showToast(`تم التبديل إلى المعرّف [${id}] بنجاح!`);
        }}
      />
    </div>
  );
}
