import React, { useState } from 'react';
import { UserProfile } from '../types';
import {
  Search,
  X,
  UserPlus,
  Check,
  Clock,
  Sparkles,
  MessageSquare,
  AlertCircle
} from 'lucide-react';

interface SearchModalProps {
  currentUserId: string;
  isOpen: boolean;
  onClose: () => void;
  friendsIds: string[];
  sentRequestIds: string[];
  onSendFriendRequest: (targetId: string) => Promise<boolean>;
  onOpenChat: (friend: UserProfile) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  currentUserId,
  isOpen,
  onClose,
  friendsIds,
  sentRequestIds,
  onSendFriendRequest,
  onOpenChat
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UserProfile[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [loadingMap, setLoadingMap] = useState<Record<string, boolean>>({});
  const [errorMsg, setErrorMsg] = useState('');

  const suggestedIds = [
    { id: '000100', name: 'روبوت الدعم 🤖', bio: 'مساعد ذكي للاختبار والترحيب' },
    { id: '555777', name: 'سارة أحمد 🎨', bio: 'مصممة واجهات ومحبة للتقنية' },
    { id: '888999', name: 'عمر خالد 💻', bio: 'مبرمج تطبيقات ومحب للمراسلة' }
  ];

  const handleSearch = async (searchTerm?: string) => {
    const term = (searchTerm !== undefined ? searchTerm : query).trim();
    if (!term) return;

    setIsSearching(true);
    setErrorMsg('');
    try {
      const res = await fetch(`/api/search?id=${encodeURIComponent(term)}`);
      const data = await res.json();
      if (data.success) {
        // filter out current user
        setResults(data.users.filter((u: UserProfile) => u.id !== currentUserId));
      } else {
        setResults([]);
        setErrorMsg(data.message || 'لم يتم العثور على نتائج');
      }
    } catch (err) {
      console.error(err);
      setErrorMsg('تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setIsSearching(false);
      setHasSearched(true);
    }
  };

  const handleSendRequest = async (targetId: string) => {
    setLoadingMap((prev) => ({ ...prev, [targetId]: true }));
    try {
      const success = await onSendFriendRequest(targetId);
      if (success) {
        // Updated state will reflect in sentRequestIds prop
      }
    } finally {
      setLoadingMap((prev) => ({ ...prev, [targetId]: false }));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">البحث عن معرّف (ID)</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1 text-right">
          {/* Search Input Bar */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300">
              أدخل المعرّف المكون من 6 أرقام (مثال: 555777 أو 000100)
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setQuery(val);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleSearch();
                    }
                  }}
                  placeholder="000000"
                  maxLength={6}
                  className="w-full bg-slate-800/90 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-2.5 text-white font-mono text-base tracking-widest outline-none transition text-center"
                />
              </div>
              <button
                type="button"
                onClick={() => handleSearch()}
                disabled={isSearching || !query.trim()}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-sm font-semibold transition cursor-pointer flex items-center gap-1.5 shrink-0 shadow-md shadow-indigo-600/30"
              >
                {isSearching ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>بحث</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick suggestions */}
          <div className="space-y-2 pt-1">
            <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              معرّفات مقترحة للاختبار:
            </span>
            <div className="flex flex-wrap gap-2">
              {suggestedIds.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setQuery(item.id);
                    handleSearch(item.id);
                  }}
                  className="flex items-center gap-2 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/70 px-3 py-1.5 rounded-xl text-xs transition cursor-pointer"
                >
                  <span className="font-mono text-indigo-300 font-bold">{item.id}</span>
                  <span className="text-slate-300 font-medium">{item.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Search Results */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-semibold text-slate-300">
                نتائج البحث
              </span>
              {hasSearched && (
                <span className="text-[11px] text-slate-400">
                  {results.length} مستخدم
                </span>
              )}
            </div>

            {isSearching && (
              <div className="py-8 text-center text-slate-400 flex flex-col items-center gap-2">
                <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-xs">جارٍ البحث عن المعرّف...</span>
              </div>
            )}

            {!isSearching && errorMsg && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {!isSearching && hasSearched && results.length === 0 && !errorMsg && (
              <div className="py-8 text-center text-slate-500 space-y-1">
                <p className="text-sm">لم يتم العثور على مستخدم بهذا المعرّف</p>
                <p className="text-xs text-slate-600">
                  تأكد من كتابة الأرقام الستة بشكل صحيح
                </p>
              </div>
            )}

            {!isSearching && results.length > 0 && (
              <div className="space-y-2.5">
                {results.map((user) => {
                  const isFriend = friendsIds.includes(user.id);
                  const isPending = sentRequestIds.includes(user.id);
                  const isLoading = loadingMap[user.id];

                  return (
                    <div
                      key={user.id}
                      className="bg-slate-800/50 hover:bg-slate-800 border border-slate-700/60 rounded-2xl p-3 flex items-center justify-between gap-3 transition"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="relative shrink-0">
                          <img
                            src={user.avatar}
                            alt={user.name}
                            className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-700 bg-slate-900"
                          />
                          {user.isOnline && (
                            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
                          )}
                        </div>

                        <div className="min-w-0 text-right">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm truncate">
                              {user.name}
                            </h4>
                            <span className="font-mono text-xs font-bold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
                              {user.id}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 truncate mt-0.5">
                            {user.bio || 'مستخدم في دردشة المعرّف'}
                          </p>
                        </div>
                      </div>

                      {/* Action Button */}
                      <div className="shrink-0">
                        {isFriend ? (
                          <button
                            type="button"
                            onClick={() => {
                              onOpenChat(user);
                              onClose();
                            }}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold transition cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>مراسلة</span>
                          </button>
                        ) : isPending ? (
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/15 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-medium">
                            <Clock className="w-3.5 h-3.5" />
                            <span>طلب قيد الانتظار</span>
                          </div>
                        ) : (
                          <button
                            type="button"
                            disabled={isLoading}
                            onClick={() => handleSendRequest(user.id)}
                            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow transition cursor-pointer"
                          >
                            {isLoading ? (
                              <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                            ) : (
                              <>
                                <UserPlus className="w-3.5 h-3.5" />
                                <span>إضافة صديق</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
