import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';
import {
  X,
  Camera,
  Upload,
  Check,
  Copy,
  Sparkles,
  User,
  FileText,
  Calendar,
  ShieldCheck,
  Share2
} from 'lucide-react';

interface ProfileModalProps {
  user: UserProfile;
  friendsCount: number;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (updated: Partial<UserProfile>) => Promise<void>;
}

// Curated avatar choices for instant selection
const PRESET_AVATARS = [
  'https://api.dicebear.com/7.x/bottts/svg?seed=Felix',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Bella',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Oscar',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Aiden',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Zoe',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Liam',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah555',
  'https://api.dicebear.com/7.x/avataaars/svg?seed=Omar888',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Gizmo',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Spark',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Nova',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Cosmo'
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  user,
  friendsCount,
  isOpen,
  onClose,
  onUpdate
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState(user.name);
  const [avatar, setAvatar] = useState(user.avatar);
  const [bio, setBio] = useState(user.bio);
  const [isSaving, setIsSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [imageError, setImageError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setImageError('يرجى اختيار ملف صورة صالح (PNG, JPG, WebP)');
      return;
    }

    // Limit to 4MB
    if (file.size > 4 * 1024 * 1024) {
      setImageError('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 4 ميجابايت');
      return;
    }

    setImageError('');
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const base64 = uploadEvent.target?.result as string;
      setAvatar(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(user.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onUpdate({
        name: name.trim() || user.name,
        avatar,
        bio: bio.trim()
      });
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">ملف الحساب الشخصي</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-right">
          {/* Top ID Card Showcase */}
          <div className="bg-gradient-to-r from-indigo-950/60 via-slate-800/60 to-purple-950/60 border border-indigo-500/20 rounded-2xl p-4 flex items-center justify-between gap-4">
            <div className="flex flex-col">
              <span className="text-xs text-indigo-300 font-medium">معرّفك الفريد (ID)</span>
              <span className="font-mono text-2xl font-black text-white tracking-widest">
                {user.id}
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                لا يحتاج لحساب أو كلمة مرور، شاركه مع أي شخص ليبدأ محادثة معك
              </span>
            </div>
            <button
              type="button"
              onClick={handleCopyId}
              className="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md transition cursor-pointer shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  <span>تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>نسخ المعرّف</span>
                </>
              )}
            </button>
          </div>

          {/* Profile Picture Section */}
          <div className="space-y-3">
            <label className="block text-sm font-semibold text-slate-300">
              صورة الحساب
            </label>
            <div className="flex items-center gap-4">
              <div className="relative group">
                <img
                  src={avatar}
                  alt="Avatar preview"
                  className="w-20 h-20 rounded-2xl object-cover ring-4 ring-indigo-500/30 bg-slate-800 shadow-lg"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-black/50 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white"
                  title="تغيير الصورة"
                >
                  <Camera className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium rounded-xl transition cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-indigo-400" />
                    <span>رفع صورة من جهازك</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const randomSeed = Math.random().toString(36).substring(7);
                      setAvatar(`https://api.dicebear.com/7.x/bottts/svg?seed=${randomSeed}`);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium rounded-xl transition cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>صورة عشوائية</span>
                  </button>
                </div>
                {imageError && (
                  <p className="text-xs text-rose-400 font-medium">{imageError}</p>
                )}
                <p className="text-[11px] text-slate-400">
                  يمكنك رفع صورتك الخاصة أو اختيار أحد النماذج الجاهزة أدناه
                </p>
              </div>
            </div>

            {/* Quick Presets Carousel / Grid */}
            <div className="space-y-1.5 pt-2">
              <span className="text-xs text-slate-400 font-medium">أو اختر رمزاً مميزاً:</span>
              <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1">
                {PRESET_AVATARS.map((presetUrl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setAvatar(presetUrl)}
                    className={`relative w-11 h-11 rounded-xl p-0.5 shrink-0 transition-transform hover:scale-105 cursor-pointer bg-slate-800 border ${
                      avatar === presetUrl
                        ? 'border-indigo-500 ring-2 ring-indigo-500/50'
                        : 'border-slate-700/60 opacity-80 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={presetUrl}
                      alt={`Avatar preset ${idx}`}
                      className="w-full h-full rounded-lg object-cover"
                    />
                    {avatar === presetUrl && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-600 rounded-full flex items-center justify-center text-white">
                        <Check className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Name Field */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-300">
              اسم العرض (الاسم المستعار)
            </label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={30}
                required
                placeholder="اكتب اسمك أو لقبك هنا..."
                className="w-full bg-slate-800/80 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-2.5 text-white text-sm outline-none transition"
              />
              <span className="absolute left-3 top-3 text-[11px] text-slate-500">
                {name.length}/30
              </span>
            </div>
          </div>

          {/* Bio / Status Field */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-300">
              الحالة / نبذة قصيرة
            </label>
            <div className="relative">
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={100}
                rows={2}
                placeholder="اكتب حالة أو نبذة عنك..."
                className="w-full bg-slate-800/80 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-2.5 text-white text-sm outline-none resize-none transition"
              />
              <span className="absolute left-3 bottom-2.5 text-[11px] text-slate-500">
                {bio.length}/100
              </span>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[11px] text-slate-400">عدد الأصدقاء</span>
                <span className="text-sm font-bold text-white">{friendsCount} صديق</span>
              </div>
            </div>

            <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <Calendar className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[11px] text-slate-400">تاريخ الإنشاء</span>
                <span className="text-xs font-semibold text-white">
                  {new Date(user.createdAt).toLocaleDateString('ar-EG')}
                </span>
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 text-sm font-medium transition cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/30 transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>جارٍ الحفظ...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>حفظ التعديلات</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
