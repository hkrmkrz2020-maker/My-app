import React, { useState } from 'react';
import { UserProfile } from '../types';
import {
  MessageSquare,
  Search,
  UserCheck,
  User,
  Copy,
  Check,
  Sparkles,
  Wifi,
  WifiOff,
  UserPlus,
  RefreshCw
} from 'lucide-react';

interface NavbarProps {
  currentUser: UserProfile;
  isConnected: boolean;
  pendingRequestsCount: number;
  sentRequestsCount: number;
  onOpenProfile: () => void;
  onOpenSearch: () => void;
  onOpenRequests: (initialTab?: 'sent' | 'received') => void;
  onNewIdentity: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  isConnected,
  pendingRequestsCount,
  sentRequestsCount,
  onOpenProfile,
  onOpenSearch,
  onOpenRequests,
  onNewIdentity
}) => {
  const [copied, setCopied] = useState(false);

  const copyIdToClipboard = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(currentUser.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-sm backdrop-blur-md bg-slate-900/95">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        {/* App Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white font-bold">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base md:text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                دردشة المعرّف
              </h1>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                ID Chat
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              {isConnected ? (
                <span className="flex items-center gap-1 text-emerald-400 text-[11px]">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  متصل بالشبكة
                </span>
              ) : (
                <span className="flex items-center gap-1 text-amber-400 text-[11px]">
                  <WifiOff className="w-3 h-3" />
                  جارٍ إعادة الاتصال...
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Current User ID Banner / Badge */}
        <div className="flex items-center gap-2">
          <button
            onClick={copyIdToClipboard}
            title="انقر لنسخ المعرّف الخاص بك"
            className="group relative flex items-center gap-2.5 bg-slate-800/90 hover:bg-slate-700/80 border border-slate-700/80 hover:border-indigo-500/50 px-3 py-1.5 rounded-xl transition-all shadow-sm cursor-pointer"
          >
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-slate-400 font-medium">معرّفك الخاص</span>
              <span className="font-mono text-sm md:text-base font-bold tracking-widest text-indigo-300 group-hover:text-indigo-200">
                {currentUser.id}
              </span>
            </div>
            <div className="w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center group-hover:bg-indigo-500 group-hover:text-white transition-colors">
              {copied ? <Check className="w-4 h-4 text-emerald-400 group-hover:text-white" /> : <Copy className="w-3.5 h-3.5" />}
            </div>
            {copied && (
              <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-emerald-600 text-white text-[11px] font-medium px-2 py-0.5 rounded shadow-lg whitespace-nowrap animate-fade-in">
                تم نسخ المعرّف بنجاح!
              </span>
            )}
          </button>
        </div>

        {/* Actions Buttons */}
        <div className="flex items-center gap-2">
          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-slate-200 px-3 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
            title="البحث عن معرّف صديق"
          >
            <Search className="w-4 h-4 text-indigo-400" />
            <span className="hidden md:inline">بحث عن آيدي</span>
          </button>

          {/* Friend Requests Button (Sent & Received) */}
          <button
            onClick={() => onOpenRequests('sent')}
            className="relative flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 px-3 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
            title="الطلبات المرسلة وقائمة الطلبات"
          >
            <UserCheck className="w-4 h-4 text-indigo-400" />
            <span className="hidden md:inline">الطلبات</span>
            {sentRequestsCount > 0 && (
              <span className="hidden sm:inline-flex items-center justify-center text-[11px] px-1.5 py-0.2 rounded-full bg-slate-700 text-slate-300 border border-slate-600" title="طلبات مرسلة">
                {sentRequestsCount} مرسلة
              </span>
            )}
            {pendingRequestsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-xs font-bold flex items-center justify-center animate-bounce">
                {pendingRequestsCount}
              </span>
            )}
          </button>

          {/* User Profile Button */}
          <button
            onClick={onOpenProfile}
            className="flex items-center gap-2.5 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 p-1.5 md:px-3 md:py-1.5 rounded-xl transition cursor-pointer"
            title="ملف الحساب والصورة الشخصية"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-8 h-8 rounded-lg object-cover ring-2 ring-indigo-500/40 bg-slate-800"
            />
            <div className="hidden lg:flex flex-col text-right">
              <span className="text-xs font-semibold text-slate-200 truncate max-w-[90px]">
                {currentUser.name}
              </span>
              <span className="text-[10px] text-emerald-400">الملف الشخصي</span>
            </div>
          </button>

          {/* Switch Identity / Generate New ID button */}
          <button
            onClick={onNewIdentity}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
            title="إنشاء معرّف جديد أو تبديل الحساب"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
