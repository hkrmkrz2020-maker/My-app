import React, { useState } from 'react';
import { FriendItem, UserProfile } from '../types';
import {
  Search,
  UserPlus,
  MessageSquare,
  Users,
  Sparkles,
  MoreVertical,
  CheckCheck
} from 'lucide-react';

interface ChatSidebarProps {
  friends: FriendItem[];
  activeFriendId: string | null;
  onSelectFriend: (friend: FriendItem) => void;
  onOpenSearch: () => void;
  currentUserId: string;
}

export const ChatSidebar: React.FC<ChatSidebarProps> = ({
  friends,
  activeFriendId,
  onSelectFriend,
  onOpenSearch,
  currentUserId
}) => {
  const [filterText, setFilterText] = useState('');
  const [filterOnlineOnly, setFilterOnlineOnly] = useState(false);

  const filteredFriends = friends.filter((f) => {
    const matchesQuery =
      f.name.toLowerCase().includes(filterText.toLowerCase()) ||
      f.id.includes(filterText);
    const matchesOnline = !filterOnlineOnly || f.isOnline;
    return matchesQuery && matchesOnline;
  });

  return (
    <aside className="w-full md:w-80 lg:w-96 bg-slate-900 border-l border-slate-800 flex flex-col h-full shrink-0">
      {/* Top Search & Filter */}
      <div className="p-4 border-b border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-400" />
            <span className="font-bold text-white text-sm">المحادثات والأصدقاء</span>
            <span className="text-[11px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
              {friends.length}
            </span>
          </div>

          <button
            onClick={onOpenSearch}
            className="flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/10 px-2.5 py-1.5 rounded-xl border border-indigo-500/20 transition cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>إضافة آيدي</span>
          </button>
        </div>

        {/* Search input in friends */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-2.5" />
          <input
            type="text"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            placeholder="بحث في الأصدقاء أو المعرّف..."
            className="w-full bg-slate-800/80 border border-slate-700/80 focus:border-indigo-500 rounded-xl pr-9 pl-4 py-2 text-xs text-white placeholder-slate-500 outline-none transition"
          />
        </div>

        {/* Online filter pill */}
        <div className="flex items-center gap-2 text-[11px]">
          <button
            type="button"
            onClick={() => setFilterOnlineOnly(!filterOnlineOnly)}
            className={`px-2.5 py-1 rounded-lg border transition cursor-pointer flex items-center gap-1.5 ${
              filterOnlineOnly
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-semibold'
                : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-300'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>المتصلون الآن فقط</span>
          </button>
        </div>
      </div>

      {/* Friends & Chats List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {filteredFriends.length === 0 ? (
          <div className="py-12 px-4 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-800/60 text-slate-500 flex items-center justify-center mx-auto">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-semibold text-slate-300">
                {friends.length === 0 ? 'لا توجد محادثات بعد' : 'لا توجد نتائج مطابقة'}
              </p>
              <p className="text-xs text-slate-500 leading-relaxed">
                {friends.length === 0
                  ? 'ابحث عن معرّف صديق أو أضف أحد المعرّفات المقترحة لبدء الدردشة الفورية!'
                  : 'جرب البحث برقم المعرّف أو تغيير كلمات البحث'}
              </p>
            </div>
            {friends.length === 0 && (
              <button
                type="button"
                onClick={onOpenSearch}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow transition cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>إضافة صديق بالمعرّف</span>
              </button>
            )}
          </div>
        ) : (
          filteredFriends.map((friend) => {
            const isActive = activeFriendId === friend.id;
            const lastMsg = friend.lastMessage;
            const unreadCount = friend.unreadCount || 0;

            const formatTime = (ts?: number) => {
              if (!ts) return '';
              const date = new Date(ts);
              const now = new Date();
              if (date.toDateString() === now.toDateString()) {
                return date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
              }
              return date.toLocaleDateString('ar-EG', { month: 'numeric', day: 'numeric' });
            };

            return (
              <button
                key={friend.id}
                type="button"
                onClick={() => onSelectFriend(friend)}
                className={`w-full text-right p-3 rounded-2xl transition flex items-center gap-3 cursor-pointer group ${
                  isActive
                    ? 'bg-indigo-600/15 border border-indigo-500/30'
                    : 'hover:bg-slate-800/70 border border-transparent'
                }`}
              >
                {/* Avatar with Online Ring */}
                <div className="relative shrink-0">
                  <img
                    src={friend.avatar}
                    alt={friend.name}
                    className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-700 bg-slate-900 group-hover:scale-102 transition-transform"
                  />
                  <span
                    className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 border-2 border-slate-900 rounded-full ${
                      friend.isOnline ? 'bg-emerald-500' : 'bg-slate-600'
                    }`}
                    title={friend.isOnline ? 'متصل الآن' : 'غير متصل'}
                  ></span>
                </div>

                {/* Info & Last message */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h3 className={`font-bold text-sm truncate ${isActive ? 'text-indigo-200' : 'text-white'}`}>
                      {friend.name}
                    </h3>
                    <span className="text-[10px] text-slate-500 shrink-0 font-medium">
                      {formatTime(lastMsg?.timestamp)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-1 mt-1">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="font-mono text-[11px] font-semibold text-indigo-400/80 shrink-0">
                        #{friend.id}
                      </span>
                      <p className="text-xs text-slate-400 truncate">
                        {lastMsg ? lastMsg.text : friend.bio || 'انقر للبدء بالمحادثة'}
                      </p>
                    </div>

                    {unreadCount > 0 && (
                      <span className="shrink-0 w-5 h-5 rounded-full bg-indigo-600 text-white text-[11px] font-bold flex items-center justify-center animate-pulse shadow-sm">
                        {unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </aside>
  );
};
