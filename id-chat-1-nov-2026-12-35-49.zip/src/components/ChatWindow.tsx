import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, FriendItem } from '../types';
import {
  Send,
  Smile,
  Image as ImageIcon,
  Check,
  CheckCheck,
  ArrowRight,
  MoreVertical,
  UserX,
  Copy,
  Sparkles,
  Paperclip,
  X
} from 'lucide-react';

interface ChatWindowProps {
  currentUserId: string;
  activeFriend: FriendItem | null;
  messages: ChatMessage[];
  isTyping: boolean;
  onSendMessage: (text: string, mediaUrl?: string) => Promise<void>;
  onSendTyping: (isTyping: boolean) => void;
  onBackToSidebar: () => void;
  onRemoveFriend: (friendId: string) => Promise<void>;
  onOpenSearch: () => void;
}

const QUICK_EMOJIS = ['👋', '❤️', '😂', '👍', '🔥', '✨', '☕', '🌹', '🙏', '🎉'];

export const ChatWindow: React.FC<ChatWindowProps> = ({
  currentUserId,
  activeFriend,
  messages,
  isTyping,
  onSendMessage,
  onSendTyping,
  onBackToSidebar,
  onRemoveFriend,
  onOpenSearch
}) => {
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);

    // Emit typing signal
    onSendTyping(true);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      onSendTyping(false);
    }, 1500);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('يرجى اختيار ملف صورة صالح');
      return;
    }

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setSelectedImage(uploadEvent.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() && !selectedImage) return;

    const textToSend = inputText;
    const imgToSend = selectedImage;

    setInputText('');
    setSelectedImage(null);
    setShowEmojiPicker(false);
    onSendTyping(false);

    setIsSending(true);
    try {
      await onSendMessage(textToSend, imgToSend || undefined);
    } finally {
      setIsSending(false);
    }
  };

  const copyFriendId = () => {
    if (activeFriend) {
      navigator.clipboard.writeText(activeFriend.id);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  if (!activeFriend) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-slate-950/60 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shadow-lg">
          <Sparkles className="w-8 h-8" />
        </div>
        <div className="max-w-md space-y-2">
          <h2 className="text-xl font-bold text-white">اختر صديقاً لبدء المراسلة</h2>
          <p className="text-sm text-slate-400 leading-relaxed">
            تطبيق مراسلة فوري بسيط يعتمد فقط على معرّفك الشخصي. يمكنك البحث عن معرّف صديق أو دعوته لمحادثتك الآن!
          </p>
        </div>
        <button
          onClick={onOpenSearch}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-indigo-600/30 transition cursor-pointer flex items-center gap-2"
        >
          <span>البحث عن آيدي وإضافته</span>
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950/40 relative">
      {/* Chat Header */}
      <div className="h-16 px-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0 backdrop-blur-md z-10">
        <div className="flex items-center gap-3 min-w-0">
          {/* Back button on mobile */}
          <button
            onClick={onBackToSidebar}
            className="md:hidden p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
            title="رجوع للقائمة"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          <div className="relative shrink-0">
            <img
              src={activeFriend.avatar}
              alt={activeFriend.name}
              className="w-10 h-10 rounded-xl object-cover ring-2 ring-indigo-500/30 bg-slate-800"
            />
            {activeFriend.isOnline && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
            )}
          </div>

          <div className="min-w-0 text-right">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-white text-sm md:text-base truncate">
                {activeFriend.name}
              </h2>
              <button
                type="button"
                onClick={copyFriendId}
                title="نسخ معرّف الصديق"
                className="font-mono text-xs font-bold text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 px-2 py-0.5 rounded border border-indigo-500/30 transition flex items-center gap-1 cursor-pointer"
              >
                <span>{activeFriend.id}</span>
                {copiedId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
              {activeFriend.isOnline ? (
                <span className="text-emerald-400 font-medium">متصل الآن</span>
              ) : (
                <span>غير متصل حالياً</span>
              )}
              {activeFriend.bio && <span className="truncate max-w-[150px] md:max-w-xs">• {activeFriend.bio}</span>}
            </div>
          </div>
        </div>

        {/* Top Header Actions */}
        <div className="relative flex items-center gap-1">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
            title="خيارات المحادثة"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {showMenu && (
            <div className="absolute left-0 top-12 w-48 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl py-1.5 z-30 animate-fade-in text-right">
              <button
                onClick={() => {
                  copyFriendId();
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
              >
                <Copy className="w-4 h-4 text-indigo-400" />
                <span>نسخ المعرّف ({activeFriend.id})</span>
              </button>
              <div className="h-px bg-slate-800 my-1"></div>
              <button
                onClick={() => {
                  if (confirm(`هل أنت متأكد من حذف ${activeFriend.name} من قائمة أصدقائك؟`)) {
                    onRemoveFriend(activeFriend.id);
                  }
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 cursor-pointer"
              >
                <UserX className="w-4 h-4 text-rose-400" />
                <span>حذف من الأصدقاء</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3">
        {messages.length === 0 ? (
          <div className="py-16 text-center space-y-2 text-slate-500">
            <p className="text-sm">ابدأ المحادثة الآن مع {activeFriend.name}!</p>
            <p className="text-xs">المراسلة مشفرة وفورية بدون وسطاء</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.fromId === currentUserId;
            const timeStr = new Date(msg.timestamp).toLocaleTimeString('ar-EG', {
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fade-in`}
              >
                <div
                  className={`max-w-[85%] md:max-w-md lg:max-w-lg rounded-2xl px-4 py-2.5 shadow-sm text-sm ${
                    isMe
                      ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-br-xs'
                      : 'bg-slate-800 text-slate-100 rounded-bl-xs border border-slate-700/60'
                  }`}
                >
                  {/* Image attachment if exists */}
                  {msg.mediaUrl && (
                    <div className="mb-2 overflow-hidden rounded-xl bg-black/20">
                      <img
                        src={msg.mediaUrl}
                        alt="Shared media"
                        className="max-h-64 w-auto object-cover rounded-xl"
                      />
                    </div>
                  )}

                  {/* Text content */}
                  {msg.text && (
                    <p className="whitespace-pre-wrap leading-relaxed break-words text-right">
                      {msg.text}
                    </p>
                  )}

                  {/* Message meta: time + read ticks */}
                  <div
                    className={`flex items-center gap-1.5 justify-end mt-1 text-[10px] ${
                      isMe ? 'text-indigo-200' : 'text-slate-400'
                    }`}
                  >
                    <span>{timeStr}</span>
                    {isMe && (
                      <span>
                        {msg.read ? (
                          <CheckCheck className="w-3.5 h-3.5 text-sky-300 inline" />
                        ) : (
                          <Check className="w-3.5 h-3.5 text-indigo-300/80 inline" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* Real-time typing indicator */}
        {isTyping && (
          <div className="flex items-center gap-2 text-slate-400 text-xs py-1 animate-fade-in">
            <div className="flex items-center gap-1 bg-slate-800/80 px-3 py-1.5 rounded-2xl border border-slate-700">
              <span className="font-medium text-indigo-300">{activeFriend.name}</span>
              <span className="text-slate-400">يكتب الآن</span>
              <span className="flex gap-1 ml-1">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.4s]"></span>
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Selected Image Preview before sending */}
      {selectedImage && (
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <img
              src={selectedImage}
              alt="Preview"
              className="w-14 h-14 object-cover rounded-xl ring-1 ring-slate-700"
            />
            <span className="text-xs text-slate-300 font-medium">صورة جاهزة للإرسال</span>
          </div>
          <button
            onClick={() => setSelectedImage(null)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Emoji Picker Popup Bar */}
      {showEmojiPicker && (
        <div className="px-4 py-2 bg-slate-900/95 border-t border-slate-800 flex items-center gap-2 overflow-x-auto">
          {QUICK_EMOJIS.map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() => {
                setInputText((prev) => prev + emoji);
              }}
              className="text-lg p-1.5 hover:bg-slate-800 rounded-xl transition hover:scale-120 cursor-pointer"
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* Message Input Bar */}
      <form
        onSubmit={handleSend}
        className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 shrink-0"
      >
        <button
          type="button"
          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
          className={`p-2.5 rounded-xl transition cursor-pointer ${
            showEmojiPicker ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
          title="رموز تعبيرية"
        >
          <Smile className="w-5 h-5" />
        </button>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageUpload}
          accept="image/*"
          className="hidden"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          title="إرسال صورة"
        >
          <ImageIcon className="w-5 h-5" />
        </button>

        <input
          type="text"
          value={inputText}
          onChange={handleInputChange}
          placeholder="اكتب رسالتك هنا..."
          className="flex-1 bg-slate-800/90 border border-slate-700/80 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-2xl px-4 py-2.5 text-white text-sm outline-none transition text-right"
        />

        <button
          type="submit"
          disabled={isSending || (!inputText.trim() && !selectedImage)}
          className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-2xl transition cursor-pointer shadow-md shadow-indigo-600/30 flex items-center justify-center shrink-0"
          title="إرسال"
        >
          <Send className="w-5 h-5 rtl:-scale-x-100" />
        </button>
      </form>
    </div>
  );
};
