import React, { useState } from 'react';
import { FriendRequest, UserProfile } from '../types';
import {
  X,
  UserCheck,
  Send,
  Inbox,
  Check,
  Trash2,
  MessageSquare,
  Clock,
  AlertCircle,
  Sparkles
} from 'lucide-react';

interface RequestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sentRequests: FriendRequest[];
  receivedRequests: FriendRequest[];
  initialTab?: 'sent' | 'received';
  onAcceptRequest: (requestId: string) => Promise<void>;
  onRejectRequest: (requestId: string) => Promise<void>;
  onCancelSentRequest: (requestId: string) => Promise<void>;
  onOpenChat: (user: UserProfile) => void;
  onOpenSearch: () => void;
}

export const RequestsModal: React.FC<RequestsModalProps> = ({
  isOpen,
  onClose,
  sentRequests,
  receivedRequests,
  initialTab = 'sent',
  onAcceptRequest,
  onRejectRequest,
  onCancelSentRequest,
  onOpenChat,
  onOpenSearch
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'sent' | 'received'>(initialTab);
  const [processingId, setProcessingId] = useState<string | null>(null);

  const handleAction = async (requestId: string, fn: (id: string) => Promise<void>) => {
    setProcessingId(requestId);
    try {
      await fn(requestId);
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">إدارة طلبات الصداقة</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-800 px-6 pt-3 gap-4">
          <button
            type="button"
            onClick={() => setActiveTab('sent')}
            className={`pb-3 text-sm font-semibold transition cursor-pointer flex items-center gap-2 relative ${
              activeTab === 'sent'
                ? 'text-indigo-400 border-b-2 border-indigo-500'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>الطلبات التي أرسلتها</span>
            {sentRequests.length > 0 && (
              <span className="text-[11px] px-1.5 py-0.2 rounded-full bg-slate-800 text-indigo-300 border border-slate-700">
                {sentRequests.length}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('received')}
            className={`pb-3 text-sm font-semibold transition cursor-pointer flex items-center gap-2 relative ${
              activeTab === 'received'
                ? 'text-indigo-400 border-b-2 border-indigo-500'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Inbox className="w-4 h-4" />
            <span>الطلبات الواردة</span>
            {receivedRequests.length > 0 && (
              <span className="text-[11px] px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-bold">
                {receivedRequests.length}
              </span>
            )}
          </button>
        </div>

        {/* List Content */}
        <div className="p-6 overflow-y-auto space-y-3 flex-1 text-right">
          {activeTab === 'sent' ? (
            /* Sent Requests (رؤية الأصدقاء الذين أرسلت لهم طلب) */
            sentRequests.length === 0 ? (
              <div className="py-12 text-center space-y-3 text-slate-400">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
                  <Send className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-slate-300">
                    لم تقم بإرسال أي طلب صداقة حتى الآن
                  </p>
                  <p className="text-xs text-slate-500">
                    ابحث عن معرّف أي صديق (6 أرقام) وأرسل له طلباً لتظهر هنا حالته
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenSearch();
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md transition cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>البحث عن معرّف وإرسال طلب</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-xs text-slate-400 font-medium pb-1">
                  قائمة بجميع المعرّفات التي أرسلت لها طلب وحالة كل طلب:
                </div>
                {sentRequests.map((req) => {
                  const target = req.receiverProfile;
                  const isProcessing = processingId === req.id;

                  return (
                    <div
                      key={req.id}
                      className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between gap-3 transition shadow-sm"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="relative shrink-0">
                          <img
                            src={target?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${req.toId}`}
                            alt={target?.name || req.toId}
                            className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-700 bg-slate-900"
                          />
                          {target?.isOnline && (
                            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
                          )}
                        </div>

                        <div className="min-w-0 text-right">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm truncate">
                              {target?.name || 'مستخدم'}
                            </h4>
                            <span className="font-mono text-xs font-bold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
                              {req.toId}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 truncate mt-0.5">
                            {target?.bio || 'في انتظار قبول الصداقة'}
                          </p>
                          <span className="text-[11px] text-slate-500 block mt-1">
                            أرسل في: {new Date(req.createdAt).toLocaleDateString('ar-EG', {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        </div>
                      </div>

                      {/* Status & Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        {req.status === 'pending' && (
                          <div className="flex items-center gap-2">
                            <span className="flex items-center gap-1 text-xs text-amber-400 bg-amber-400/10 border border-amber-400/20 px-2.5 py-1 rounded-xl">
                              <Clock className="w-3.5 h-3.5" />
                              <span>قيد الانتظار</span>
                            </span>
                            <button
                              type="button"
                              disabled={isProcessing}
                              onClick={() => handleAction(req.id, onCancelSentRequest)}
                              title="إلغاء الطلب"
                              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}

                        {req.status === 'accepted' && (
                          <div className="flex items-center gap-2">
                            <span className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-2.5 py-1 rounded-xl">
                              <Check className="w-3.5 h-3.5" />
                              <span>تم القبول!</span>
                            </span>
                            {target && (
                              <button
                                type="button"
                                onClick={() => {
                                  onOpenChat(target);
                                  onClose();
                                }}
                                className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition cursor-pointer"
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                                <span>مراسلة</span>
                              </button>
                            )}
                          </div>
                        )}

                        {req.status === 'rejected' && (
                          <span className="text-xs text-rose-400 bg-rose-400/10 border border-rose-400/20 px-2.5 py-1 rounded-xl">
                            تم الرفض
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : (
            /* Received Requests */
            receivedRequests.length === 0 ? (
              <div className="py-12 text-center space-y-2 text-slate-400">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
                  <Inbox className="w-6 h-6" />
                </div>
                <p className="text-sm font-medium text-slate-300">
                  لا توجد طلبات صداقة جديدة واردة
                </p>
                <p className="text-xs text-slate-500">
                  عندما يرسل لك شخص طلب صداقة عبر معرّفك، ستظهر هنا للموافقة أو الرفض
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {receivedRequests.map((req) => {
                  const sender = req.senderProfile;
                  const isProcessing = processingId === req.id;

                  return (
                    <div
                      key={req.id}
                      className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between gap-3 transition shadow-sm"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="relative shrink-0">
                          <img
                            src={sender?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${req.fromId}`}
                            alt={sender?.name || req.fromId}
                            className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-700 bg-slate-900"
                          />
                          {sender?.isOnline && (
                            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
                          )}
                        </div>

                        <div className="min-w-0 text-right">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm truncate">
                              {sender?.name || 'مستخدم جديد'}
                            </h4>
                            <span className="font-mono text-xs font-bold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
                              {req.fromId}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 truncate mt-0.5">
                            {sender?.bio || 'يرغب في إضافتك إلى قائمة الأصدقاء'}
                          </p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          disabled={isProcessing}
                          onClick={() => handleAction(req.id, onAcceptRequest)}
                          className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow transition cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>قبول</span>
                        </button>

                        <button
                          type="button"
                          disabled={isProcessing}
                          onClick={() => handleAction(req.id, onRejectRequest)}
                          className="px-3 py-2 bg-slate-700 hover:bg-rose-600/30 hover:text-rose-300 hover:border-rose-500/30 border border-slate-600 text-slate-300 rounded-xl text-xs font-semibold transition cursor-pointer"
                        >
                          رفض
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
