import React, { useState } from 'react';
import {
  Sparkles,
  RefreshCw,
  KeyRound,
  Check,
  X,
  ShieldCheck,
  User
} from 'lucide-react';

interface IdentitySetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectId: (id: string, name?: string) => Promise<void>;
  currentId?: string;
}

export const IdentitySetupModal: React.FC<IdentitySetupModalProps> = ({
  isOpen,
  onClose,
  onSelectId,
  currentId
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'generate' | 'enter'>('generate');
  const [customId, setCustomId] = useState('');
  const [nickName, setNickName] = useState('');
  const [randomIdPreview, setRandomIdPreview] = useState(() =>
    Math.floor(Math.random() * 1000000).toString().padStart(6, '0')
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const generateNewRandom = () => {
    const newId = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
    setRandomIdPreview(newId);
  };

  const handleConfirm = async () => {
    setIsSubmitting(true);
    setErrorMsg('');
    try {
      if (mode === 'generate') {
        await onSelectId(randomIdPreview, nickName.trim() || undefined);
        onClose();
      } else {
        if (!/^\d{6}$/.test(customId)) {
          setErrorMsg('يرجى إدخال معرّف صحيح مكون من 6 أرقام بالضبط (مثال: 123456)');
          setIsSubmitting(false);
          return;
        }
        await onSelectId(customId, nickName.trim() || undefined);
        onClose();
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'حدث خطأ أثناء ضبط المعرّف');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col text-right">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">
              {currentId ? 'إنشاء معرّف جديد أو تبديله' : 'مرحباً بك في دردشة المعرّف'}
            </h2>
          </div>
          {currentId && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          <div className="text-sm text-slate-300 leading-relaxed">
            تطبيق مراسلة فوري <span className="font-bold text-indigo-400">بدون حساب</span> أو تسجيل دخول. يتم توليد معرّف عشوائي فريد من 6 أرقام (من 000000 إلى 999999) لاستخدامه مباشرة!
          </div>

          {/* Mode switch */}
          <div className="grid grid-cols-2 gap-2 bg-slate-800/80 p-1 rounded-2xl border border-slate-700">
            <button
              type="button"
              onClick={() => {
                setMode('generate');
                setErrorMsg('');
              }}
              className={`py-2 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'generate'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>توليد آيدي عشوائي</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('enter');
                setErrorMsg('');
              }}
              className={`py-2 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'enter'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>دخول بمعرّف سابق</span>
            </button>
          </div>

          {mode === 'generate' ? (
            <div className="space-y-4">
              {/* Random ID Preview card */}
              <div className="bg-gradient-to-r from-indigo-950/70 via-slate-800/80 to-purple-950/70 border border-indigo-500/30 rounded-2xl p-5 text-center space-y-2">
                <span className="text-xs text-indigo-300 font-medium">
                  المعرّف العشوائي المخصص لك:
                </span>
                <div className="font-mono text-3xl font-black text-white tracking-widest">
                  {randomIdPreview}
                </div>
                <button
                  type="button"
                  onClick={generateNewRandom}
                  className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 hover:underline pt-1 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>توليد رقم عشوائي آخر</span>
                </button>
              </div>

              {/* Optional Name */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  اسم العرض (اختياري)
                </label>
                <input
                  type="text"
                  value={nickName}
                  onChange={(e) => setNickName(e.target.value)}
                  placeholder="مثال: فهد، نورة، مستخدم..."
                  maxLength={30}
                  className="w-full bg-slate-800 border border-slate-700 focus:border-indigo-500 rounded-xl px-4 py-2 text-white text-sm outline-none transition"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  أدخل المعرّف (6 أرقام)
                </label>
                <input
                  type="text"
                  value={customId}
                  onChange={(e) => {
                    const clean = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setCustomId(clean);
                  }}
                  placeholder="000000"
                  maxLength={6}
                  className="w-full bg-slate-800 border border-slate-700 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-white font-mono text-center text-lg tracking-widest outline-none transition"
                />
                <span className="text-[11px] text-slate-500 block">
                  إذا كنت قد استخدمت هذا المعرّف من قبل ستستعيد بياناتك وأصدقائك
                </span>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-xs">
              {errorMsg}
            </div>
          )}

          {/* Privacy note */}
          <div className="flex items-center gap-2 text-slate-400 text-xs bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>لا يتطلب أي بيانات شخصية، بريد إلكتروني، أو كلمة مرور.</span>
          </div>

          {/* Submit */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={handleConfirm}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/30 transition cursor-pointer flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>
                  {mode === 'generate' ? 'البدء بهذا المعرّف' : 'تسجيل الدخول بالمعرّف'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
